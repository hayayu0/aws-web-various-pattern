const http = require('http');
const fs = require('fs');
const server = http.createServer(function (req, res) {
    res.writeHead(200);
    const htmlfile = (req.url == '/sorry') ? 'sorry' : '404';
    res.write(fs.readFileSync(htmlfile));
    res.end();
});
server.listen(3000);
