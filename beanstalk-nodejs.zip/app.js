const http = require('http');
const fs = require('fs');
const server = http.createServer(function (req, res) {
    res.writeHead(200);
    res.write(fs.readFileSync('sorry.html'));
    res.end();
});
server.listen(3000);
